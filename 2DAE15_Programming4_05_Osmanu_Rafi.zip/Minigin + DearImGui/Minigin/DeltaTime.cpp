#include "DeltaTime.h"

dae::DeltaTime* dae::DeltaTime::instance = nullptr;