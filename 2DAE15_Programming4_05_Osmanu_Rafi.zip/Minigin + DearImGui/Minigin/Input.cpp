#include "Input.h"

using namespace dae;

void Input::AddCommand(const ControllerKey& key, std::shared_ptr<Command> command)
{
	m_ControllerCommands[key] = std::move(command);
}

void dae::Input::AddCommand(const KeyboardKey& key, std::shared_ptr<Command> command)
{
	m_KeyboardCommands[key] = std::move(command);
}


