#include "Commands.h"
#include "DeltaTime.h"

dae::MoveCommand::MoveCommand(const std::shared_ptr<GameObject> actor, glm::vec3 direction, float speed)
	:m_Actor{actor}
	,m_Direction{direction}
	,m_Speed{speed}
{
}

void dae::MoveCommand::Execute()
{
	auto translation = glm::vec3(m_Actor->GetLocalPosition(), 0) + (m_Direction * m_Speed * DeltaTime::GetInstance().getDeltaTime());

	m_Actor->SetLocalPosition({ translation.x, translation.y });
}
