#include <SDL.h>
#include "InputManager.h"
#include "imgui_impl_sdl2.h"
#include "Input.h"
using namespace dae;

bool dae::InputManager::ProcessInput()
{

	SDL_Event e;

	auto controllers = Input::GetInstance().GetControllers();
	auto ControllerCommands = Input::GetInstance().GetControllerCommands();
	auto KeyboardCommands = Input::GetInstance().GetKeyboardCommands();

	for (const auto& controller : controllers)
	{
		controller->Update();
	}

	for (const auto& comm : ControllerCommands)
	{
		//get controller index from key
		auto& controller = controllers[comm.first.first];

		//get button from key
		auto button = comm.first.second;

		//if the right button is down on controller execute command
		if (controller->IsDownThisFrame(button))
		{
			comm.second->Execute();
		}
	}
	
	while (SDL_PollEvent(&e)) {
		if (e.type == SDL_QUIT) {
			return false;
		}
		if (e.type == SDL_KEYDOWN) {
			
		}
		if (e.type == SDL_MOUSEBUTTONDOWN) {
			
		}
		// procces event for imgui
		ImGui_ImplSDL2_ProcessEvent(&e);
		
	}

	const Uint8* KeyState = SDL_GetKeyboardState(nullptr);
	for (const auto& comm : KeyboardCommands)
	{
		if (KeyState[comm.first.first])
		{
			comm.second->Execute();
		}
	}

	return true;
}


