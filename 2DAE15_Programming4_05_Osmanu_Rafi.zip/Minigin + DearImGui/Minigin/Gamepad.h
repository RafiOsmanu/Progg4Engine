#pragma once
#include <memory>

namespace dae
{

	class Gamepad 
	{
	public:
		explicit Gamepad(int controllerIndex);
		~Gamepad();

		enum class ControllerButton
		{
			DPadUp = 0x0001,
			DPadDown = 0x0002,
			DPadLeft = 0x0004,
			DPadRight = 0x0008
		};

		void Update();

		bool IsDownThisFrame(ControllerButton button) const;

		bool IsUpThisFrame(ControllerButton button) const;

		bool IsPressed(ControllerButton button) const;

	private:
		class ControllerImpl;
		std::unique_ptr<ControllerImpl> m_pImpl;
	};
}

