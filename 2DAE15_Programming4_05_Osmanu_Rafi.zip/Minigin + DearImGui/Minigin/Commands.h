#pragma once
#include "GameObject.h"
#include "MoveComponent.h"
namespace dae
{
	class Command
	{
	public:
		virtual ~Command() = default;
		virtual void Execute() {};
	};

	class MoveCommand : public Command
	{
	public:
		MoveCommand(const std::shared_ptr<GameObject> actor, glm::vec3 direction, float speed);
		virtual void Execute() override;
	private:
		std::shared_ptr<GameObject> m_Actor;
		glm::vec3 m_Direction;
		float m_Speed;
	};
	
}

