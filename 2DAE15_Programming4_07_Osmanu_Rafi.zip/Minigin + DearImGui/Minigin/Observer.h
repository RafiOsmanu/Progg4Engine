#pragma once
#include "BaseComponent.h"
#include"DataTypes.h"
namespace dae
{
	class Observer
	{
	public:
		Observer() {};
		Observer(const Observer&) = delete;
		Observer(Observer&&) = delete;
		Observer& operator= (const Observer&) = delete;
		Observer& operator= (const Observer&&) = delete;

		virtual void Notify(BaseComponent* component, EventType eventType) = 0;
	};
}

