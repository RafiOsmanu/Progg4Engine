#pragma once
#include <memory>
#include "GameObject.h"
#include "TextObject.h"
#include "Observer.h"


namespace dae
{
	class HealthComponent;

	class DeathObserver final : public Observer
	{
	public:
		DeathObserver() = default;

		void Notify(BaseComponent* component, EventType eventType) override;
	};

}
