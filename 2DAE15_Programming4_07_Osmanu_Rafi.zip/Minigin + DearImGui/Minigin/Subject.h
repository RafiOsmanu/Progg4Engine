#pragma once
#include <vector>
#include<algorithm>
#include "Observer.h"


namespace dae
{
	class Subject final
	{
	public:
		//observer code

		void AddObserver(Observer* observer) {
			m_observers.push_back(observer);
		}

		void RemoveObserver(Observer* observer) {
			m_observers.erase(std::remove(m_observers.begin(), m_observers.end(), observer), m_observers.end());
		}

		// Method to notify observers of player death
		void NotifyObservers(EventType eventType, BaseComponent* component) {
			for (auto observer : m_observers) {
				observer->Notify(component, eventType);
			}
		}
	private:

		std::vector<Observer*> m_observers;
	};
}

