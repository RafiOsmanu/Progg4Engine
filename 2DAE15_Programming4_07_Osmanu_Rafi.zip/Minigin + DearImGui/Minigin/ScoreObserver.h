#pragma once
#include <memory>
#include "GameObject.h"
#include "TextObject.h"
#include "Observer.h"


namespace dae
{
	class ScoreComponent;

	class ScoreObserver final : public Observer
	{
	public:
		ScoreObserver() = default;
		
		void Notify(BaseComponent* component, EventType eventType) override;
	};

}

