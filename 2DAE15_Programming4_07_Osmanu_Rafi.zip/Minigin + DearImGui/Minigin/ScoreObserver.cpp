#include "ScoreObserver.h"
#include "ScoreComponent.h"


void dae::ScoreObserver::Notify(BaseComponent* component, EventType eventType)
{
    TextObject* display = static_cast<ScoreComponent*>(component)->GetOwner().lock()->GetComponent<TextObject>().get();
    switch (eventType)
    {
    case dae::PlayerScoreAdd:

        float score = static_cast<ScoreComponent*>(component)->GetCurrentScore();

        display->SetText("Score: " + std::to_string(score));

        break;
    }
}
