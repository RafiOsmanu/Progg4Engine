#include "DeathObserver.h"
#include "HealthComponent.h"


namespace dae
{
    
    void DeathObserver::Notify(BaseComponent* component, EventType eventType)
    {
        TextObject* display = static_cast<HealthComponent*>(component)->GetOwner().lock()->GetComponent<TextObject>().get();
        switch (eventType)
        {
        case dae::PlayerDied:
            
            display->SetText("Player Died");
           
            break;
        case dae::PlayerDamage:

            int health = static_cast<HealthComponent*>(component)->GetCurrentHealth();
        
            display->SetText("Remaining Lives: " + std::to_string(health));
           
            break;
        }
    }
}
