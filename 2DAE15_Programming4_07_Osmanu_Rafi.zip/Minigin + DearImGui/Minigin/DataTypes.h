#pragma once
namespace dae
{
	enum EventType {
		PlayerDied,
		PlayerDamage,
		PlayerScoreAdd
	};
}

